package com.example.Book.ServiceImpl;



	import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Book.Entity.Book;
import com.example.Book.Repo.BookRepo;


	@Service
	public class ServiceImpl {

		@Autowired
		private BookRepo rpo;
		
		
		public String deleteBook(int id) {
			rpo.deleteById(id);
			return id+" is deleted";
		}

		
		public Book inserBook(Book ed) {
			
			
			return rpo.save(ed);
		}

		
		public Book updateBook(Book bk, int id) {
			
			Book wd = rpo.findById(id).get();
			wd.setId(bk.getId());
			wd.setAuthor(bk.getAuthor());
			wd.setPages(bk.getPages());
			wd.setPrice(bk.getPrice());
			
			return rpo.save(wd);
		}

		
		public Book getBook(int id) {
			
			return rpo.findById(id).get();
		}

		
		public List<Book> getalldata() {
			
			return rpo.findAll();
		}

	}

