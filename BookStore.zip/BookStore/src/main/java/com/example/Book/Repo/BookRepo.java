package com.example.Book.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Book.Entity.Book;


public interface BookRepo extends JpaRepository<Book, Integer> {

}
